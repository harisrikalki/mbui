﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace MediBlog.Models
{
    public class ConsultationModel
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int ConsultationId { get; set; }
        [Required]
        public int UserId { get; set; }
        [Required]
        public string PatientName { get; set; }
        [Required]
        public string MobileNumber { get; set; }
        [Required]
        public string EmailId { get; set; }
        public string Country { get; set; }
        public string State { get; set; }
        public int Age { get; set; }
        [Required]
        public string Gender { get; set; }
        public DateTime? AppointmentDate { get; set; }
        public string Description { get; set; }

        [Required]
        public int SpecialityId { get; set; }

        public decimal? ConsultationFee { get; set; }
    }
}
