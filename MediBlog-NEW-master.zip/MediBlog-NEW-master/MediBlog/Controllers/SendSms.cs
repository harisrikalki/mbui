﻿using System;
using Vonage;
using Vonage.Request;

namespace MediBlog.Controllers
{
	public class SendSms
	{
        public void Execute()
        {
            var TO_NUMBER = "9441276125";
            var VONAGE_BRAND_NAME = "DevTest";

            Console.WriteLine(TO_NUMBER + VONAGE_BRAND_NAME);

        }
    }
}
