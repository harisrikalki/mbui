﻿using AutoMapper;
using MediBlog.Dto;
using MediBlog.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;

namespace MediBlog.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class ConsultationController : ControllerBase
    {
        private IConfiguration _config;
        private readonly MediBlogContext _mediBlogContext;
        private readonly IMapper _mapper;

        public ConsultationController(
            IConfiguration config,
            MediBlogContext mediBlogContext,
            IMapper mapper)
        {
            _config = config;
            _mediBlogContext = mediBlogContext;
            _mapper = mapper;

        }

        [HttpPost]
        [Route("submitconsultation")]
        public IActionResult SubmitConsultation([FromBody]ConsultationDto consultationDto)
        {

            ConsultationModel consultationModel = _mapper.Map<ConsultationModel>(consultationDto);
            if(_mediBlogContext.ConsultationModels.Any(x => x.ConsultationId == consultationModel.ConsultationId))
            {
                _mediBlogContext.ConsultationModels.Update(consultationModel);
                string Username = "MediBlog";
                string Password = "Welcome@123";
                string SenderId = "NSSSKK";
                string MNumber = "917075751881";
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string json = (new WebClient()).DownloadString("https://cloud.smsindiahub.in/vendorsms/pushsms.aspx?user=Mediblog&password=Welcome@123&msisdn=917075751881&sid=NSSSKK&msg=Dear%20Customer,%0A%0AYou%20have%20successfully%20registered%20for%20online%20doctor%20consultation%20with%20us.Our%20representative%20will%20get%20in%20touch%20with%20you%20soon.%0A%0AThank%20you%0AMediBlog&fl=0&gwid=2");

                //Return the JSON string.
                return Content(json);
            }
            else { _mediBlogContext.ConsultationModels.Add(consultationModel);
                string Username = "MediBlog";
                string Password = "Welcome@123";
                string SenderId = "NSSSKK";
                string MNumber = "917075751881";
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string json = (new WebClient()).DownloadString("https://cloud.smsindiahub.in/vendorsms/pushsms.aspx?user=Mediblog&password=Welcome@123&msisdn=917075751881&sid=NSSSKK&msg=Dear%20Customer,%0A%0AYou%20have%20successfully%20registered%20for%20online%20doctor%20consultation%20with%20us.Our%20representative%20will%20get%20in%20touch%20with%20you%20soon.%0A%0AThank%20you%0AMediBlog&fl=0&gwid=2");

                //Return the JSON string.
                return Content(json);
            }
            _mediBlogContext.SaveChanges();

            

            return Ok(new { });
        }
    }
}
