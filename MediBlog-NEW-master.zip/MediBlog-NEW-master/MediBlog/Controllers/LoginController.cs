﻿using AutoMapper;
using MediBlog.Dto;
using MediBlog.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net;
using System.Security.Claims;
using System.Text;
using System.Net.Http;


namespace MediBlog.Controllers
{

    [AllowAnonymous]
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        private IConfiguration _config;
        private readonly MediBlogContext _mediBlogContext;
        private readonly IMapper _mapper;

        public LoginController(IConfiguration config,
            MediBlogContext mediBlogContext,
            IMapper mapper)
        {
            _config = config;
            _mediBlogContext = mediBlogContext;
            _mapper = mapper;
        }

        public class Account
        {
            public string CustomerId { get; set; }
            public bool Name { get; set; }
            public bool Country { get; set; }
        }
        [HttpPost]
        [Route("login")]
        public IActionResult Login([FromBody] LoginDto login)
        {
            IActionResult response = Unauthorized();
            var user = AuthenticateUser(login);

            if (user != null)
            {
                var tokenString = GenerateJSONWebToken(user);
                response = Ok(new { token = tokenString });
            }

            return response;
        }

        [HttpPost]
        [Route("signup")]
        public IActionResult SignUp([FromBody] SignUpDto signupdto)
        {
            ResponseDto responseDto = new ResponseDto();

            bool isExistingUser = _mediBlogContext.UserModels.Any(x => (x.EmailAddress == signupdto.EmailAddress || x.PhoneNo == signupdto.PhoneNo));
            if (isExistingUser)
            {
                responseDto = new ResponseDto()
                {
                    ResultCode = HttpStatusCode.BadRequest,
                    Result = JsonConvert.SerializeObject(new { errorMessage = "User already exits" })
                };
                return BadRequest(responseDto);
            };


            UserModel userModel = _mapper.Map<UserModel>(signupdto);

            userModel.CreationTime = DateTime.Now;
            userModel.UpdationTime = DateTime.Now;
            _mediBlogContext.UserModels.Add(userModel);
            _mediBlogContext.SaveChanges();
            

            return Ok(responseDto);
        }

        [HttpPost]
        [Route("forgotpassword")]
        public IActionResult ForGotPassword ([FromBody] ForGotDto forGotDto)
        {
            ResponseDto responseDto = new ResponseDto();

           var dbUser = _mediBlogContext.UserModels.Where(x => x.PhoneNo == forGotDto.Username);
            if (dbUser!=null) {

                UserModel userModel = _mapper.Map<UserModel>(dbUser);
                //918686433748
                //string Username = "MediBlog";
                //string Password = "Welcome@123";
                //string SenderId = "NSSSKK";
                //string MNumber = "919533973980";
                //string Message = "Dear Customer,\n\nYou have successfully registered for online doctor consultation with us.Our representative will get in touch with you soon.\n\nThank you\nMediBlog";
                ServicePointManager.Expect100Continue = true;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                string json = (new WebClient()).DownloadString("https://cloud.smsindiahub.in/vendorsms/pushsms.aspx?user=Mediblog&password=Welcome@123&msisdn=91"+ forGotDto.Username + "&sid=NSSSKK&msg=Dear%20Customer,%0A%0AYou%20can%20reset%20your%20password%20using%20the%20given%20link.%0A%0A%20Thank%20you,%20%0AMediBlog&fl=0&gwid=2");

                //////NEED to save OTP
                userModel.ResetOTP = "";
                
                userModel.UpdationTime = DateTime.Now;
                _mediBlogContext.UserModels.Update(userModel);
                _mediBlogContext.SaveChanges();


                //Return the JSON string.
                return Content(json);

                
            }
            else {
                return BadRequest(responseDto);
            }

            return Ok(responseDto);
        }


        [HttpPost]
        [Route("resetpassword")]
        public IActionResult ResetPassword([FromBody] ForGotDto forGotDto)
        {
            ResponseDto responseDto = new ResponseDto();

            var dbUser = _mediBlogContext.UserModels.FirstOrDefault(x => x.PhoneNo == forGotDto.Username && x.ResetOTP == forGotDto.ResetOTP);


            if (dbUser != null )
            {

                UserModel userModel = _mapper.Map<UserModel>(dbUser);

                userModel.ResetOTP = string.Empty;
                userModel.Password = forGotDto.Password;
                userModel.UpdationTime = DateTime.Now;
                _mediBlogContext.UserModels.Update(userModel);
                _mediBlogContext.SaveChanges();
            }
            else
            {
                return BadRequest(responseDto);
            }

            return Ok(responseDto);
        }
        private string GenerateJSONWebToken(LoginDto userInfo)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);

            var claims = new[] {
                new Claim(JwtRegisteredClaimNames.Sub, userInfo.Username),
                new Claim(JwtRegisteredClaimNames.Email, userInfo.EmailAddress),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
            };

            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
                _config["Jwt:Issuer"],
                claims,
                expires: DateTime.Now.AddMinutes(20),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private LoginDto AuthenticateUser(LoginDto user)
        {
            var dbUser = _mediBlogContext.UserModels.FirstOrDefault(x => x.PhoneNo == user.Username && x.Password == user.Password);

            return dbUser == null ? null : user;
        }
    }
}
