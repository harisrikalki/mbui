﻿using MediBlog.Models;
using MediBlog.Models.EntityConfigurations;
using Microsoft.EntityFrameworkCore;

namespace MediBlog
{
    public class MediBlogContext : DbContext
    {

        public MediBlogContext(DbContextOptions<MediBlogContext> dbContextOptions) :
            base(dbContextOptions)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            new UserMapping().Configure(modelBuilder.Entity<UserModel>());
            
            
            modelBuilder.Entity<SpecialityModel>().ToTable("Speciality");
            modelBuilder.Entity<ConsultationModel>().ToTable("Consultation");
        }

        public DbSet<UserModel> UserModels { get; set; }
        public DbSet<SpecialityModel> SpecialityModels { get; set; }
        public DbSet<ConsultationModel> ConsultationModels { get; set; }
    }
}
